﻿<!doctype html>
<html lang="fr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Plateforme locale pour encourager le don de sang, trouver un centre et prendre un engagement de don.">
    <meta name="theme-color" content="#b51f32">
    <meta property="og:title" content="Don de Sang Solidaire - Accueil">
    <meta property="og:description" content="Plateforme locale pour encourager le don de sang en Haïti.">
    <meta property="og:type" content="website">
    <title>Don de Sang Solidaire - Accueil</title>
    <link rel="stylesheet" href="styles.css">
  </head>
  <body>
    <a href="#main-content" class="skip-link">Aller au contenu principal</a>
    
    <div class="utility-bar">
      <span>Urgence et orientation: <a href="tel:+50944842854">+509 4484 2854</a></span>
      <span>Contribution MonCash: <a href="tel:+50944842854">+509 4484 2854</a></span>
    </div>

    <header class="site-header">
      <a class="brand" href="index.php" aria-label="Don de Sang Solidaire">
        <span class="brand-mark" aria-hidden="true"></span>
        <span>Don de Sang Solidaire</span>
      </a>
      <nav class="main-nav" aria-label="Navigation principale">
        <a class="is-active" href="index.php">Accueil</a>
        <a href="pourquoi.php">Pourquoi donner</a>
        <a href="conseils.php">Conseils</a>
        <a href="conditions.php">Conditions</a>
        <a href="urgences.php">Besoins urgents</a>
        <a href="centres.php">Centres</a>
        <a href="faq.php">FAQ</a>
        <a href="demande.php">Demander du sang</a>
        <a href="contact.php">Contacts</a>
        <a href="admin.php">Admin</a>
        <a class="nav-cta" href="engagement.php">Je donne</a>
      </nav>
      <button class="language-toggle" id="languageToggle" type="button" aria-label="Changer de langue">Kreyol</button>
    </header>

    <main id="main-content">
      <section class="hero" id="accueil">
        <canvas id="heroCanvas" class="hero-canvas" aria-hidden="true"></canvas>
        <div class="hero-content">
          <p class="eyebrow">Campagne communautaire</p>
          <h2>Chaque don de sang peut aider jusqu'à trois personnes.</h2>
          <p class="hero-copy">
            Mobilisez votre quartier, trouvez un point de collecte et laissez vos coordonnées
            pour être recontacté lors de la prochaine campagne.
          </p>
          <div class="hero-actions">
            <a class="button primary" href="engagement.php">Prendre engagement</a>
            <a class="button secondary" href="demande.php">Demander du sang</a>
            <a class="button secondary" href="centres.php">Voir les centres</a>
          </div>
        </div>
        <aside class="hero-panel" aria-label="Resume de la campagne">
          <strong>Objectif du mois</strong>
          <span class="big-number">250</span>
          <span>promesses de don</span>
          <div class="progress" aria-label="Progression: 62 pour cent">
            <span style="width: 62%"></span>
          </div>
          <ul class="trust-list">
            <li>Données protégées</li>
            <li>Contacts vérifiés</li>
            <li>Suivi administrateur</li>
          </ul>
        </aside>
      </section>

      <section class="stats-band" aria-label="Chiffres importants">
        <div><strong>10 min</strong><span>pour le prélèvement</span></div>
        <div><strong>56 jours</strong><span>entre deux dons</span></div>
        <div><strong>18-65 ans</strong><span>âge général recommandé</span></div>
      </section>

      <section class="content-section process-section" id="processus">
        <div class="section-heading">
          <div><p class="eyebrow">Fonctionnement</p><h2>Un parcours simple et organisé</h2></div>
          <p class="section-note">Le site aide l'équipe à recevoir, vérifier et suivre les demandes sans perdre les informations importantes.</p>
        </div>
        <div class="process-grid">
          <article><span>1</span><h3>Inscription ou demande</h3><p>Le visiteur remplit le formulaire adapté à sa situation: donner du sang ou faire une demande.</p></article>
          <article><span>2</span><h3>Vérification</h3><p>L'équipe consulte les informations dans l'espace admin et vérifie les contacts nécessaires.</p></article>
          <article><span>3</span><h3>Suivi rapide</h3><p>Les messages WhatsApp et les filtres par groupe sanguin facilitent la coordination.</p></article>
        </div>
      </section>
    </main>

    <footer class="site-footer">
      <p>Don de Sang Solidaire</p>
      <p>En cas d'urgence médicale, contactez directement un centre de santé ou les services competents.</p>
    </footer>

    <a class="whatsapp-button" href="https://wa.me/50944842854?text=Bonjour%2C%20je%20souhaite%20avoir%20des%20informations%20sur%20le%20don%20de%20sang" target="_blank" rel="noopener noreferrer">WhatsApp</a>
    <script src="script.js"></script>
  </body>
</html>