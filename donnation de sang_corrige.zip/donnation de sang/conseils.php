﻿<!doctype html>
<html lang="fr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Plateforme locale pour encourager le don de sang, trouver un centre et prendre un engagement de don.">
    <meta name="theme-color" content="#b51f32">
    <meta property="og:title" content="Conseils - Don de Sang Solidaire">
    <meta property="og:description" content="Plateforme locale pour encourager le don de sang en Haïti.">
    <meta property="og:type" content="website">
    <title>Conseils - Don de Sang Solidaire</title>
    <link rel="stylesheet" href="styles.css">
  </head>
  <body>
    <a href="#main-content" class="skip-link">Aller au contenu principal</a>
    
    <div class="utility-bar">
      <span>Urgence et orientation: <a href="tel:+50944842854">+509 4484 2854</a></span>
      <span>Contribution MonCash: <a href="tel:+50944842854">+509 4484 2854</a></span>
    </div>

     <header class="site-header">
      <a class="brand" href="index.php" aria-label="Don de Sang Solidaire">
        <span class="brand-mark" aria-hidden="true"></span>
        <span>Don de Sang Solidaire</span>
      </a>
      <nav class="main-nav" aria-label="Navigation principale">
        <a class="is-active" href="index.php">Accueil</a>
        <a href="pourquoi.php">Pourquoi donner</a>
        <a href="conseils.php">Conseils</a>
        <a href="conditions.php">Conditions</a>
        <a href="urgences.php">Besoins urgents</a>
        <a href="centres.php">Centres</a>
        <a href="faq.php">FAQ</a>
        <a href="demande.php">Demander du sang</a>
        <a href="contact.php">Contacts</a>
        <a href="admin.php">Admin</a>
        <a class="nav-cta" href="engagement.php">Je donne</a>
      </nav>
      <button class="language-toggle" id="languageToggle" type="button" aria-label="Changer de langue">Kreyol</button>
    </header>

    <main id="main-content">
<section class="content-section tips-section" id="conseils">
        <div class="section-heading">
          <div><p class="eyebrow">Conseils pratiques</p><h2>Bien se préparer avant et après le don</h2></div>
          <p class="section-note">Ces conseils aident les donneurs à arriver plus confiants et mieux préparés.</p>
        </div>
        <div class="tips-grid">
          <article><strong>Avant le don</strong><ul><li>Dormir suffisamment la veille.</li><li>Manger un repas léger, sans excès de gras.</li><li>Boire de l'eau avant de venir.</li></ul></article>
          <article><strong>Pendant la visite</strong><ul><li>Signaler tout malaise ou traitement médical.</li><li>Rester détendu pendant le prélèvement.</li><li>Suivre les indications de l'équipe.</li></ul></article>
          <article><strong>Après le don</strong><ul><li>Prendre la collation proposée.</li><li>Éviter les efforts physiques importants.</li><li>Boire régulièrement dans la journée.</li></ul></article>
        </div>
      </section>
    </main>

    <footer class="site-footer">
      <p>Don de Sang Solidaire</p>
      <p>En cas d'urgence médicale, contactez directement un centre de santé ou les services competents.</p>
    </footer>

    <a class="whatsapp-button" href="https://wa.me/50944842854?text=Bonjour%2C%20je%20souhaite%20avoir%20des%20informations%20sur%20le%20don%20de%20sang" target="_blank" rel="noopener noreferrer">WhatsApp</a>
    <script src="script.js"></script>
  </body>
</html>


