﻿<!doctype html>
<html lang="fr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Plateforme locale pour encourager le don de sang, trouver un centre et prendre un engagement de don.">
    <meta name="theme-color" content="#b51f32">
    <meta property="og:title" content="Besoins urgents - Don de Sang Solidaire">
    <meta property="og:description" content="Plateforme locale pour encourager le don de sang en Haïti.">
    <meta property="og:type" content="website">
    <title>Besoins urgents - Don de Sang Solidaire</title>
    <link rel="stylesheet" href="styles.css">
  </head>
  <body>
    <a href="#main-content" class="skip-link">Aller au contenu principal</a>
    
    <div class="utility-bar">
      <span>Urgence et orientation: <a href="tel:+50944842854">+509 4484 2854</a></span>
      <span>Contribution MonCash: <a href="tel:+50944842854">+509 4484 2854</a></span>
    </div>

  <header class="site-header">
      <a class="brand" href="index.php" aria-label="Don de Sang Solidaire">
        <span class="brand-mark" aria-hidden="true"></span>
        <span>Don de Sang Solidaire</span>
      </a>
      <nav class="main-nav" aria-label="Navigation principale">
        <a class="is-active" href="index.php">Accueil</a>
        <a href="pourquoi.php">Pourquoi donner</a>
        <a href="conseils.php">Conseils</a>
        <a href="conditions.php">Conditions</a>
        <a href="urgences.php">Besoins urgents</a>
        <a href="centres.php">Centres</a>
        <a href="faq.php">FAQ</a>
        <a href="demande.php">Demander du sang</a>
        <a href="contact.php">Contacts</a>
        <a href="admin.php">Admin</a>
        <a class="nav-cta" href="engagement.php">Je donne</a>
      </nav>
      <button class="language-toggle" id="languageToggle" type="button" aria-label="Changer de langue">Kreyol</button>
    </header>

    <main id="main-content">
<section class="content-section urgent-section" id="urgences">
        <div class="urgent-copy">
          <p class="eyebrow">Besoins urgents</p>
          <h2>Groupes sanguins recherchés</h2>
          <p>Ces niveaux sont indicatifs pour afficher les priorités de campagne. Les responsables peuvent les modifier dans le code selon la situation.</p>
        </div>
        <div class="blood-grid" aria-label="Etat des besoins par groupe sanguin">
          <article class="blood-card critical"><strong>O-</strong><span>Critique</span></article>
          <article class="blood-card high"><strong>O+</strong><span>Élevé</span></article>
          <article class="blood-card high"><strong>A+</strong><span>Élevé</span></article>
          <article class="blood-card medium"><strong>B+</strong><span>Moyen</span></article>
          <article class="blood-card medium"><strong>AB-</strong><span>Moyen</span></article>
          <article class="blood-card stable"><strong>AB+</strong><span>Stable</span></article>
        </div>
      </section>
    </main>

    <footer class="site-footer">
      <p>Don de Sang Solidaire</p>
      <p>En cas d'urgence médicale, contactez directement un centre de santé ou les services competents.</p>
    </footer>

    <a class="whatsapp-button" href="https://wa.me/50944842854?text=Bonjour%2C%20je%20souhaite%20avoir%20des%20informations%20sur%20le%20don%20de%20sang" target="_blank" rel="noopener noreferrer">WhatsApp</a>
    <script src="script.js"></script>
  </body>
</html>


